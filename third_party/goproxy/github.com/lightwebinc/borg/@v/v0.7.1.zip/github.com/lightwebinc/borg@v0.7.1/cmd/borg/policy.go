package main

import (
	"context"
	"encoding/hex"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/lightwebinc/borg/borgrec"
	"github.com/lightwebinc/borg/internal/engine"
	"github.com/lightwebinc/borg/internal/state"
	"github.com/lightwebinc/borg/reader"
)

const roleHelp = `usage: borg role define <name> -permission P [-permission P ...]
       borg role retire <name> [-by both|set|sweep]
       borg role list

A role names the permissions it carries (service/action/resource). Define
publishes the role and the organization's next token commits to it. Retire
does both halves of a withdrawal: a token drops it from the set, and a sweep
retracts its carrier at every host. -by set or -by sweep does one of them;
the sweep takes effect as soon as it is mined and seen, the token is the
committed half. Giving a role to a member or a group is borg bind.`

const bindHelp = `usage: borg bind <role> -to <group-id|key> [-only P ...] [-expiry E]
       borg unbind <txid> [-by both|set|sweep]

A binding gives a role to one key or to a whole group: every current member
of that group holds the role. -only keeps part of the role and can never
widen it. unbind retires one binding by its carrier's txid.`

const policyHelp = `usage: borg policy [show] [-role R | -bound X] [-local]
       borg policy check <key> <permission> [-local]

show lists the organization's policy set and check decides one permission,
both read from the hosts and checked against this machine's own block
headers, as a service does. -role asks for one role's definition and every
binding that gives it, -bound for the bindings that name one group or key,
and each record then carries a path into the policy root. -local reads this
home's own record instead, which only the organization's own home holds.`

// multi collects a flag given more than once.
type multi []string

func (m *multi) String() string     { return strings.Join(*m, ",") }
func (m *multi) Set(v string) error { *m = append(*m, v); return nil }

func cmdRole(ctx context.Context, g *global, args []string) error {
	fs := g.flagSet("role", roleHelp)
	var perms multi
	fs.Var(&perms, "permission", "a permission the role carries, given once per permission")
	by := fs.String("by", "both", "retire: both, set or sweep")
	pos, err := parse(fs, args)
	if err != nil {
		return err
	}
	switch {
	case len(pos) == 2 && pos[0] == "define":
		if len(perms) == 0 {
			g.say("a role with no permission authorises nothing; a client may still show it")
		}
		return g.publishPolicy(ctx, engine.PolicyReq{Role: pos[1], Permissions: perms}, "role")
	case len(pos) == 2 && pos[0] == "retire":
		r, err := g.openOrg(ctx, true)
		if err != nil {
			return err
		}
		defer r.close(ctx, g)
		var out []*state.Policy
		for _, p := range current(r.h.st.Org) {
			if p.Role == pos[1] && p.Kind == borgrec.PolicyRole {
				out = append(out, p)
			}
		}
		if len(out) == 0 {
			return usage("no definition of %q is in the policy set", pos[1])
		}
		if *by != "both" && *by != "set" && *by != "sweep" {
			return usage("-by must be both, set or sweep")
		}
		return g.retirePolicy(ctx, r, out, *by)
	case len(pos) <= 1 && (len(pos) == 0 || pos[0] == "list"):
		r, err := g.openOrg(ctx, false)
		if err != nil {
			return err
		}
		defer r.close(ctx, g)
		roles := map[string][]string{}
		for _, p := range current(r.h.st.Org) {
			if p.Kind == borgrec.PolicyRole {
				roles[p.Role] = p.Permissions
			}
		}
		names := make([]string, 0, len(roles))
		for n := range roles {
			names = append(names, n)
		}
		sort.Strings(names)
		for _, n := range names {
			fmt.Fprintf(g.stdout, "role    %s %s\n", n, strings.Join(roles[n], " "))
		}
		if len(names) == 0 {
			g.say("this organization's policy set defines no role (borg role define)")
		}
		return nil
	}
	return usage(roleHelp)
}

func cmdBind(ctx context.Context, g *global, args []string) error {
	fs := g.flagSet("bind", bindHelp)
	to := fs.String("to", "", "the group identifier or identity key the role is given to")
	expiry := fs.String("expiry", "", "the time the binding stops authorising, YYYY-MM-DDTHH:MM:SSZ")
	var only multi
	fs.Var(&only, "only", "keep this permission of the role, given once per permission")
	pos, err := parse(fs, args)
	if err != nil {
		return err
	}
	if len(pos) != 1 {
		return usage(bindHelp)
	}
	if *to == "" {
		return usage("-to names the group identifier or the identity key the role is given to")
	}
	raw, err := hex.DecodeString(*to)
	if err != nil || (len(raw) != borgrec.GroupIDLen && len(raw) != 33) {
		return usage("-to is a group identifier (32 hex digits) or an identity key (66)")
	}
	if *expiry != "" {
		if _, err := borgrec.ParseExpiry(*expiry); err != nil {
			return usage("-expiry is YYYY-MM-DDTHH:MM:SSZ")
		}
	}
	return g.publishPolicy(ctx, engine.PolicyReq{Role: pos[0], Permissions: only, To: raw, Expiry: *expiry}, "binding")
}

func cmdUnbind(ctx context.Context, g *global, args []string) error {
	fs := g.flagSet("unbind", bindHelp)
	by := fs.String("by", "both", "both, set or sweep")
	pos, err := parse(fs, args)
	if err != nil {
		return err
	}
	if len(pos) != 1 {
		return usage(bindHelp)
	}
	r, err := g.openOrg(ctx, true)
	if err != nil {
		return err
	}
	defer r.close(ctx, g)
	p := r.h.st.Org.PolicyByTxid(pos[0])
	if p == nil {
		return usage("%s is not a policy record this organization published", pos[0])
	}
	if p.Kind != borgrec.PolicyBinding {
		return usage("%s is a role definition; retire it with borg role retire %s", pos[0], p.Role)
	}
	if *by != "both" && *by != "set" && *by != "sweep" {
		return usage("-by must be both, set or sweep")
	}
	return g.retirePolicy(ctx, r, []*state.Policy{p}, *by)
}

func cmdPolicy(ctx context.Context, g *global, args []string) error {
	fs := g.flagSet("policy", policyHelp)
	local := fs.Bool("local", false, "read this home's own record instead of the hosts")
	role := fs.String("role", "", "show one role: its definition and every binding that gives it")
	bound := fs.String("bound", "", "show the bindings whose subject is this group identifier or key")
	pos, err := parse(fs, args)
	if err != nil {
		return err
	}
	if *role != "" && *bound != "" {
		return usage("-role and -bound name different questions; ask one")
	}
	switch {
	case len(pos) <= 1 && (len(pos) == 0 || pos[0] == "show") && !*local && (*role != "" || *bound != ""):
		return g.showPolicyOf(ctx, *role, *bound)
	case len(pos) <= 1 && (len(pos) == 0 || pos[0] == "show") && !*local:
		return g.showPolicy(ctx)
	case len(pos) == 3 && pos[0] == "check" && !*local:
		return g.checkFromHosts(ctx, pos[1], pos[2])
	case len(pos) <= 1 && (len(pos) == 0 || pos[0] == "show"):
		r, err := g.openOrg(ctx, false)
		if err != nil {
			return err
		}
		defer r.close(ctx, g)
		set := current(r.h.st.Org)
		for _, p := range set {
			// A record this home swept is still in the set until a token
			// drops it, and it grants nothing from the moment the sweep is
			// mined and seen (spec section 9.5).
			swept := suffix(" RETRACTED by ", p.Swept)
			if p.Kind == borgrec.PolicyRole {
				fmt.Fprintf(g.stdout, "role    %s %s %s%s\n", p.Txid, p.Role, strings.Join(p.Permissions, " "), swept)
				continue
			}
			what := "key"
			if len(p.To) == 2*borgrec.GroupIDLen {
				what = "group"
			}
			fmt.Fprintf(g.stdout, "bind    %s %s to %s %s%s%s%s\n", p.Txid, p.Role, what, p.To,
				suffix(" only ", strings.Join(p.Permissions, " ")), suffix(" until ", p.Expiry), swept)
		}
		if len(set) == 0 {
			g.say("this organization's policy set is empty (borg role define)")
		}
		return nil
	case len(pos) == 3 && pos[0] == "check":
		return g.check(ctx, pos[1], pos[2])
	}
	return usage(policyHelp)
}

func suffix(label, v string) string {
	if v == "" {
		return ""
	}
	return label + v
}

// current is the policy set as this home knows it: defined by a token and
// not retired.
func current(o *state.Org) []*state.Policy {
	var out []*state.Policy
	if o == nil {
		return out
	}
	for i := range o.Policies {
		if o.Policies[i].Defined && !o.Policies[i].Retired {
			out = append(out, &o.Policies[i])
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Txid < out[j].Txid })
	return out
}

// publishPolicy writes one record and commits to it in one transition.
func (g *global) publishPolicy(ctx context.Context, req engine.PolicyReq, what string) error {
	r, err := g.openOrg(ctx, true)
	if err != nil {
		return err
	}
	defer r.close(ctx, g)
	// Two definitions of one role in the set are equivocation, which a
	// reader reads as the intersection of their permissions. The tooling
	// never leaves one: it retires the definition it replaces in the same
	// transition that defines the new one (spec section 5A.1).
	var replaced []*state.Policy
	defined := false
	for _, old := range current(r.h.st.Org) {
		if old.Kind == borgrec.PolicyRole && old.Role == req.Role {
			defined = true
			if req.To == nil {
				replaced = append(replaced, old)
			}
		}
	}
	// A binding names a role; it does not carry its permissions. Bound to a
	// role this set does not define, it authorizes nothing (spec 5A.4).
	if req.To != nil && !defined {
		g.say("this set defines no role %s; the binding authorizes nothing until it does", req.Role)
	}
	p, err := r.eng.PublishPolicy(ctx, req)
	if err != nil {
		return err
	}
	fmt.Fprintf(g.stdout, "%-7s %s %s %s\n", what, p.Txid, p.Role, strings.Join(p.Permissions, " "))
	if err := r.eng.OrgTransitionWith(ctx, nil, nil, []*state.Policy{r.h.st.Org.PolicyByTxid(p.Txid)}, replaced, "organization token (define)"); err != nil {
		return lost(err)
	}
	t := state.Latest(r.h.st.Org.Tokens)
	if len(replaced) > 0 {
		fmt.Fprintf(g.stdout, "org     seq %d %s defines it and retires %d it replaces\n", t.Seq, t.Txid, len(replaced))
		return g.sweepPolicies(ctx, r, replaced)
	}
	fmt.Fprintf(g.stdout, "org     seq %d %s defines it\n", t.Seq, t.Txid)
	return nil
}

// retirePolicy drops records from the set and sweeps their outputs: the
// committed half and the fast half of a withdrawal (spec section 9.5).
func (g *global) retirePolicy(ctx context.Context, r *orgRun, ps []*state.Policy, by string) error {
	o := r.h.st.Org
	if by == "both" || by == "set" {
		if err := r.eng.OrgTransitionWith(ctx, nil, nil, nil, ps, "organization token (retire)"); err != nil {
			return lost(err)
		}
		t := state.Latest(o.Tokens)
		fmt.Fprintf(g.stdout, "org     seq %d %s retires %d policy record(s)\n", t.Seq, t.Txid, len(ps))
	}
	if by == "set" {
		g.say("the records are out of the set; their carriers are not retracted (borg unbind -by sweep)")
		return nil
	}
	return g.sweepPolicies(ctx, r, ps)
}

// sweepPolicies retracts the carriers of records already out of the set.
func (g *global) sweepPolicies(ctx context.Context, r *orgRun, ps []*state.Policy) error {
	o := r.h.st.Org
	trees := map[string][]uint32{}
	var order []string
	for _, p := range ps {
		if p.Swept != "" {
			continue
		}
		if _, ok := trees[p.Tree]; !ok {
			order = append(order, p.Tree)
		}
		trees[p.Tree] = append(trees[p.Tree], p.Vout)
	}
	for _, tree := range order {
		sw, err := r.eng.Retract(ctx, o.Hall, tree, trees[tree])
		if err != nil {
			return err
		}
		fmt.Fprintf(g.stdout, "sweep   %s spends %d policy outpoint(s) of %s, mined at height %d\n", sw.Txid, len(sw.Vouts), tree, sw.Height)
	}
	return nil
}

// check folds this home's policy set for a subject, as a service would.
func (g *global) check(ctx context.Context, key, permission string) error {
	raw, _, err := parseKey("key", key)
	if err != nil {
		return err
	}
	if _, err := borgrec.Asked(permission); err != nil {
		return usage("%q is not a permission a service asks: service/action/resource, and never a wildcard", permission)
	}
	r, err := g.openOrg(ctx, false)
	if err != nil {
		return err
	}
	defer r.close(ctx, g)
	o := r.h.st.Org
	set, err := engine.Records(current(o))
	if err != nil {
		return err
	}
	subject := borgrec.Subject{Key: raw, Member: r.eng.CurrentGrant(hex.EncodeToString(raw)) != nil}
	if gr := r.eng.CurrentGrant(hex.EncodeToString(raw)); gr != nil && gr.Role != "" {
		subject.Roles = []string{gr.Role}
	}
	for i := range o.Groups {
		members, _, _ := engine.Members(&o.Groups[i])
		for _, m := range members {
			if hex.EncodeToString(m) == hex.EncodeToString(raw) {
				id, err := hex.DecodeString(o.Groups[i].ID)
				if err == nil && len(id) == borgrec.GroupIDLen {
					subject.Groups = append(subject.Groups, [borgrec.GroupIDLen]byte(id))
				}
				break
			}
		}
	}
	eff := borgrec.Effective(subject, set, time.Now())
	allowed, err := borgrec.Allows(eff, permission)
	if err != nil {
		return err
	}
	verdict := "DENY "
	if allowed {
		verdict = "ALLOW"
	}
	fmt.Fprintf(g.stdout, "%s   %s %s\n", verdict, key, permission)
	fmt.Fprintf(g.stdout, "holds   %s\n", strings.Join(eff, " "))
	g.say("this is what the organization's own state says; a service decides from a host's answers and its own headers")
	return nil
}

// showPolicy reads the organization's policy set from the hosts, verifies
// every record and holds each host's answer to the root the latest token
// commits to (spec section 13).
func (g *global) showPolicy(ctx context.Context) error {
	t, err := g.readTarget(ctx)
	if err != nil {
		return err
	}
	ov, err := t.rd.Org(ctx, t.hall, t.org)
	if err != nil {
		return g.chainProblem("the organization", err)
	}
	problem := g.reportChain("organization chain", ov.ChainView)
	cs := t.rd.CommittedSet(ctx, ov)
	for _, pa := range cs.Answers {
		if pa.Err != nil {
			g.say("host %s: NOT ASKED: %s", pa.Host, firstLine(pa.Err.Error()))
			if problem == nil {
				problem = incomplete("a host could not be asked")
			}
			continue
		}
		for _, r := range pa.Refused {
			g.say("%sREFUSED policy record %s (%s): it is not shown: %v", by(r.Host), r.Txid, r.Reason, r.Err)
			problem = incomplete("a host answered a policy record that does not verify; it is not shown")
		}
		// A host short of the set is named whether or not the set was
		// reached without it: what it lacks is what borg fill gives it.
		if !pa.Matches {
			g.say("host %s: its policy records do not reproduce the root of seq %d: it withheld or added one", pa.Host, ov.Token.Seq)
		}
	}
	if !cs.OK {
		if problem == nil {
			problem = incomplete("no host's policy set matches the committed root, and neither does what they hold between them")
		}
		return problem
	}
	if cs.Assembled {
		fmt.Fprintf(g.stdout, "set     %d record(s) assembled from %s, the root of seq %d reproduced\n", len(cs.Policies), strings.Join(cs.Hosts, " and "), ov.Token.Seq)
	} else {
		fmt.Fprintf(g.stdout, "set     %d record(s) from %s, the root of seq %d reproduced\n", len(cs.Policies), cs.Hosts[0], ov.Token.Seq)
	}
	{
		// The whole set is answered without a path (spec section 10.2), and
		// the answer, or the assembly, reproduced the root above, which is
		// what holds it. `policy show -role` and `-bound` answer with a path.
		for _, car := range cs.Policies {
			p := car.Carrier.Policy
			if p.Kind == borgrec.PolicyRole {
				fmt.Fprintf(g.stdout, "role    %s %s %s\n", car.Txid, p.Role, strings.Join(p.Permissions, " "))
				continue
			}
			what := "key"
			if p.BoundToGroup() {
				what = "group"
			}
			fmt.Fprintf(g.stdout, "bind    %s %s to %s %s%s%s\n", car.Txid, p.Role, what, hex.EncodeToString(p.To),
				suffix(" only ", strings.Join(p.Permissions, " ")), suffix(" until ", p.Expiry))
		}
	}
	return problem
}

// checkFromHosts is what a service does: the whole of spec section 13 for
// one subject and one permission, from the hosts and this machine's own
// headers, failing closed.
func (g *global) checkFromHosts(ctx context.Context, key, permission string) error {
	raw, _, err := parseKey("key", key)
	if err != nil {
		return err
	}
	if _, err := borgrec.Asked(permission); err != nil {
		return usage("%q is not a permission a service asks: service/action/resource, and never a wildcard", permission)
	}
	t, err := g.readTarget(ctx)
	if err != nil {
		return err
	}
	ov, err := t.rd.Org(ctx, t.hall, t.org)
	if err != nil {
		return g.chainProblem("the organization", err)
	}
	problem := g.reportChain("organization chain", ov.ChainView)
	d, err := t.rd.Allows(ctx, ov, raw, permission, g.spends(), time.Now())
	if err != nil {
		return err
	}
	for h, e := range d.HostErr {
		g.say("host %s: NOT ASKED: %s", h, firstLine(e.Error()))
	}
	for _, r := range d.Refused {
		g.say("%sREFUSED %s (%s): %v", by(r.Host), r.Txid, r.Reason, r.Err)
	}
	verdict := "DENY "
	if d.Allow {
		verdict = "ALLOW"
	}
	fmt.Fprintf(g.stdout, "%s   %s %s\n", verdict, key, permission)
	fmt.Fprintf(g.stdout, "holds   %s\n", strings.Join(d.Effective, " "))
	fmt.Fprintf(g.stdout, "over    seq %d %s, %d grant(s), %d policy record(s), %d group(s)\n",
		d.Seq, d.Token, len(d.Grants), len(d.Policies), len(d.Groups))
	if d.Assembled {
		fmt.Fprintf(g.stdout, "from    the policy set assembled from %s: no one host held it whole\n", strings.Join(d.Hosts, " and "))
	}
	if !d.Allow {
		fmt.Fprintf(g.stdout, "why     %s\n", d.Reason)
	}
	if d.Reason == "incomplete" {
		return incomplete("the read could not be completed, so the answer is DENY")
	}
	return problem
}

// showPolicyOf asks one role's records or one subject's bindings, each of
// which the host answers with a path into the policy root.
func (g *global) showPolicyOf(ctx context.Context, role, bound string) error {
	var to []byte
	if bound != "" {
		b, err := hex.DecodeString(bound)
		if err != nil || (len(b) != borgrec.GroupIDLen && len(b) != 33) {
			return usage("-bound is a group identifier (32 hex digits) or an identity key (66)")
		}
		to = b
	}
	if role != "" && borgrec.CheckRoleName(role) != nil {
		return usage("%q is not a role name: lower-case letters, digits, -, _ and .", role)
	}
	t, err := g.readTarget(ctx)
	if err != nil {
		return err
	}
	ov, err := t.rd.Org(ctx, t.hall, t.org)
	if err != nil {
		return g.chainProblem("the organization", err)
	}
	problem := g.reportChain("organization chain", ov.ChainView)
	var cars []*reader.Car
	var refused []reader.Refusal
	var errs map[string]error
	if role != "" {
		cars, refused, errs = t.rd.RoleOf(ctx, ov, role)
	} else {
		cars, refused, errs = t.rd.BoundTo(ctx, ov, to)
	}
	for h, e := range errs {
		g.say("host %s: NOT ASKED: %s", h, firstLine(e.Error()))
		if problem == nil {
			problem = incomplete("a host could not be asked")
		}
	}
	for _, r := range refused {
		g.say("%sREFUSED %s (%s): it is not shown: %v", by(r.Host), r.Txid, r.Reason, r.Err)
		problem = incomplete("a host answered a policy record that does not verify; it is not shown")
	}
	for _, car := range cars {
		p := car.Carrier.Policy
		path := "path INTO THE POLICY ROOT verified"
		if !ov.PolicyPathHolds(car) {
			path = "no path verified; check it against the set"
		}
		kind := "bind   "
		if p.Kind == borgrec.PolicyRole {
			kind = "role   "
		}
		fmt.Fprintf(g.stdout, "%s %s %s %s%s (%s)\n", kind, car.Txid, p.Role, strings.Join(p.Permissions, " "),
			suffix(" to ", hex.EncodeToString(p.To)), path)
	}
	if len(cars) == 0 && problem == nil {
		g.say("no host answered a record for that question")
	}
	return problem
}

// by names the host an answer came from, for a refusal that has one. A
// refusal the reader raised itself (a group its own fold does not hold)
// names no host, and must not read as though a host were at fault.
func by(host string) string {
	if host == "" {
		return ""
	}
	return "host " + host + ": "
}
