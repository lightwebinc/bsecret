package engine

import (
	"context"
	"encoding/hex"
	"strings"
	"testing"
	"time"

	ec "github.com/bsv-blockchain/go-sdk/primitives/ec"

	"github.com/lightwebinc/bcommon/bwallet"
	"github.com/lightwebinc/bcommon/nodeapi"
	"github.com/lightwebinc/bcommon/publish"

	"github.com/lightwebinc/borg/borgrec"
	"github.com/lightwebinc/borg/internal/state"
	"github.com/lightwebinc/borg/internal/testchain"
	"github.com/lightwebinc/borg/reader"
)

const hall = "example_abcdefghij"

func key(t *testing.T) []byte {
	t.Helper()
	k, err := ec.NewPrivateKey()
	if err != nil {
		t.Fatal(err)
	}
	return k.PubKey().Compressed()
}

// offline is an engine whose legs are never reached: every check here
// refuses before anything is built or sent.
func offline(t *testing.T) (*Engine, *state.State) {
	t.Helper()
	dir := t.TempDir()
	w, err := bwallet.Create(dir, Profile)
	if err != nil {
		t.Fatal(err)
	}
	st, err := state.Load(dir, w.Signer().IdentityHex())
	if err != nil {
		t.Fatal(err)
	}
	legs := Legs{Settler: &publish.TCPIngress{Addr: "192.0.2.1:1"}, Chain: &nodeapi.Asset{Base: "http://192.0.2.1"},
		Facade: &publish.Facade{Base: "http://192.0.2.1"}, Headers: testchain.New(1)}
	e, err := New(st, w.Signer(), w.Pool, legs, Options{TreeCount: 4, ChainTreeCount: 2, TreeSats: 1, Entries: 8})
	if err != nil {
		t.Fatal(err)
	}
	return e, st
}

// withGroup gives the state an organization with a group of members at
// seq 0, each holding a grant that ends at expiry.
func withGroup(t *testing.T, e *Engine, st *state.State, members [][]byte, expiry time.Time) string {
	t.Helper()
	sortKeys(members)
	o := &state.Org{Hall: hall, Name: "x", Tokens: []state.Token{{Seq: 0, Txid: strings.Repeat("ab", 32)}}}
	for _, m := range members {
		o.Grants = append(o.Grants, state.Grant{Subject: hex.EncodeToString(m), Admitted: true, Scope: "member",
			Expiry: expiry.UTC().Format(borgrec.ExpiryLayout)})
	}
	rec := &borgrec.Group{Hall: hall, Org: e.OrgKey(), Group: [16]byte{7}, Name: "g", Commitment: [32]byte{1},
		Add: members, Count: uint64(len(members)), Members: borgrec.MembersRoot(members), Created: 1}
	b, err := rec.Encode()
	if err != nil {
		t.Fatal(err)
	}
	id := hex.EncodeToString(rec.Group[:])
	o.Groups = []state.Group{{ID: id, Name: "g", Tokens: []state.Token{{Seq: 0, Txid: strings.Repeat("cd", 32), Record: hex.EncodeToString(b)}}}}
	st.Org = o
	return id
}

func TestDebtIsMembersWithoutACurrentGrant(t *testing.T) {
	e, st := offline(t)
	a, b := key(t), key(t)
	id := withGroup(t, e, st, [][]byte{a, b}, time.Now().Add(time.Hour))
	if d, err := e.Debt(st.Org.Group(id)); err != nil || len(d) != 0 {
		t.Fatalf("no debt: %v %d", err, len(d))
	}
	for i := range st.Org.Grants {
		if st.Org.Grants[i].Subject == hex.EncodeToString(b) {
			st.Org.Grants[i].Revoked = true
		}
	}
	d, err := e.Debt(st.Org.Group(id))
	if err != nil || len(d) != 1 || string(d[0]) != string(b) {
		t.Fatalf("a revoked grant is debt: %v %d", err, len(d))
	}
	e.Now = func() time.Time { return time.Now().Add(2 * time.Hour) }
	if d, _ := e.Debt(st.Org.Group(id)); len(d) != 2 {
		t.Fatalf("an expired grant is debt: %d", len(d))
	}
}

func TestGroupChangeRefusesBeforeBuilding(t *testing.T) {
	e, st := offline(t)
	a, b, stranger := key(t), key(t), key(t)
	id := withGroup(t, e, st, [][]byte{a, b}, time.Now().Add(time.Hour))
	ctx := context.Background()
	for _, c := range []struct {
		name string
		ch   Change
		want string
	}{
		{"remove a non-member", Change{Remove: [][]byte{stranger}}, "is not a member"},
		{"add a member", Change{Add: [][]byte{a}}, "is a member of group"},
		{"add a key with no grant", Change{Add: [][]byte{stranger}}, "holds no current grant"},
		{"add the organization", Change{Add: [][]byte{e.OrgKey()}}, "neither the organization nor the anyone key"},
		{"add the anyone key", Change{Add: [][]byte{borgrec.AnyoneKey()}}, "neither the organization nor the anyone key"},
		{"nothing", Change{}, "changes nothing"},
	} {
		if _, err := e.GroupChange(ctx, id, c.ch); err == nil || !strings.Contains(err.Error(), c.want) {
			t.Errorf("%s: %v, want %q", c.name, err, c.want)
		}
	}
	if _, err := e.GroupChange(ctx, strings.Repeat("00", 16), Change{Rotate: true}); err == nil {
		t.Error("an unknown group")
	}
	if _, err := e.CreateGroup(ctx, "h", [][]byte{stranger}, false, 0); err == nil || !strings.Contains(err.Error(), "holds no current grant") {
		t.Errorf("create with a key with no grant: %v", err)
	}
	if _, err := e.CreateGroup(ctx, "h", [][]byte{a, a}, false, 0); err == nil || !strings.Contains(err.Error(), "named twice") {
		t.Errorf("create with a key twice: %v", err)
	}
}

func TestLostErrorSaysTheKeyIsDiscarded(t *testing.T) {
	err := &LostError{What: "group x", Txid: strings.Repeat("a", 64), By: strings.Repeat("b", 64)}
	if !strings.Contains(err.Error(), "epoch key it sampled is discarded") || !strings.Contains(err.Error(), "bbbbbbbbbbbb") {
		t.Fatal(err)
	}
}

// A group whose current epoch holds a token the index reports
// rejoin-unrotated (one another tool built: this one never does) is still
// the organization's to run: its members fold, the flag is reported, and
// every transition of it begins a new epoch.
func TestAFlaggedGroupStaysOperable(t *testing.T) {
	e, st := offline(t)
	a, b := key(t), key(t)
	id := withGroup(t, e, st, [][]byte{a, b}, time.Now().Add(time.Hour))
	g := st.Org.Group(id)
	recs, err := GroupRecords(g)
	if err != nil {
		t.Fatal(err)
	}
	add := func(mut func(r *borgrec.Group), members [][]byte) {
		t.Helper()
		r := *recs[len(recs)-1]
		r.Seq, r.Add, r.Remove, r.Prev = r.Seq+1, nil, nil, [32]byte{9}
		mut(&r)
		sortKeys(members)
		r.Count, r.Members = uint64(len(members)), borgrec.MembersRoot(members)
		enc, err := r.Encode()
		if err != nil {
			t.Fatal(err)
		}
		g.Tokens = append(g.Tokens, state.Token{Seq: r.Seq, Txid: strings.Repeat("ef", 32), Record: hex.EncodeToString(enc)})
		recs = append(recs, &r)
	}
	// b removed with a new epoch, then added back in the same epoch.
	add(func(r *borgrec.Group) { r.Remove, r.Epoch, r.EpochSeq, r.Commitment = [][]byte{b}, 1, 1, [32]byte{2} }, [][]byte{a})
	if st, _, err := Flagged(g); err != nil || st != "" {
		t.Fatalf("a clean epoch: %q %v", st, err)
	}
	add(func(r *borgrec.Group) { r.Add = [][]byte{b} }, [][]byte{a, b})
	members, removed, err := Members(g)
	if err != nil || len(members) != 2 || !removed[string(b)] {
		t.Fatalf("the members of a flagged group: %d %v", len(members), err)
	}
	if st, at, err := Flagged(g); err != nil || st != borgrec.StatusRejoinUnrotated || at != 2 {
		t.Fatalf("flagged: %q at %d, %v", st, at, err)
	}
	// A rotation clears it: the flagged token is in an ended epoch.
	add(func(r *borgrec.Group) { r.Epoch, r.EpochSeq, r.Commitment = 2, 3, [32]byte{3} }, [][]byte{a, b})
	if st, _, err := Flagged(g); err != nil || st != "" {
		t.Fatalf("after a rotation: %q %v", st, err)
	}
}

// Every kind a home persists has a confirmation: the lookup that shows a
// host took it. A kind without one is published blind, which is what left
// policy records unconfirmed until 2026-10-11, so the set is asserted here
// rather than left to be noticed on a plane.
func TestEveryPendingKindHasAConfirmation(t *testing.T) {
	e, st := offline(t)
	e.Legs.Reader = &reader.Client{Hosts: []string{"http://192.0.2.1"}}
	st.Org = &state.Org{Hall: "example_aaaaaaaaaa",
		Policies: []state.Policy{{Txid: strings.Repeat("ab", 32), Kind: borgrec.PolicyRole, Role: "releaser"}}}
	for _, kind := range []string{state.KindGrant, state.KindPolicy, state.KindWrap,
		state.KindOrgToken, state.KindGroupToken, state.KindSweep} {
		p := state.Pending{Kind: kind, Hall: st.Org.Hall, Txid: strings.Repeat("ab", 32), Org: e.orgHex()}
		if e.confirm(p) == nil {
			t.Errorf("kind %q has no confirmation: it would be published with nothing to show a host took it", kind)
		}
	}
}
